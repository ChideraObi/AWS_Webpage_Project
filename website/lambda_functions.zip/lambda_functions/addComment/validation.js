exports.validateCommentID= function(commentid, errors){
	if (!commentid) {
        errors.push("Missing Registration Code");
	} 
}

exports.validateCommentText= function(commenttext, errors){
	if (!commenttext) {
        errors.push("Missing Thing Name");
	} 
}

exports.validateCommentUserID= function(commentuserid, errors){
	if (!commentuserid) {
        errors.push("Missing Thing User ID");
	} 
}

exports.validateCommentThingID = function(commentthingid, errors){
	if (!commentthingid) {
        errors.push("Missing Thing Registration Code");
	} 
}
