exports.validateUsername = function(userid){
	if (!userid) {
        errors.push("Missing Registration Code");
	} 
}

exports.validateEmail = function(email, errors){
	if (!email) {
        errors.push("Missing Thing Name");
	} 
}

exports.validatePasswordhash = function(passwordhash, errors){
	if (!passwordhash) {
        errors.push("Missing Thing User ID");
	} 
}

exports.validateUserID = function(userid, errors){
	if (!userid) {
        errors.push("Missing Thing Registration Code");
	} 
}
