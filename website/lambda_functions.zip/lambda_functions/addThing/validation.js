exports.validateThingID = function(thingid, errors){
	if (!thingid) {
        errors.push("Missing Registration Code");
	} 
}

exports.validateThingName = function(thingname, errors){
	if (!thingname) {
        errors.push("Missing Thing Name");
	} 
}

exports.validateThingUserID = function(thinguserid, errors){
	if (!thinguserid) {
        errors.push("Missing Thing User ID");
	} 
}

exports.validateThingRegistrationCode = function(thingregistrationcode, errors){
	if (!thingregistrationcode) {
        errors.push("Missing Thing Registration Code");
	} 
}
